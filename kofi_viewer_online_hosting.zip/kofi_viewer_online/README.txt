ONLINE DEPLOYMENT — KO-FI PUBLIC IMAGE VIEWER

This project is configured for a Python web host such as Render.

1. Extract this ZIP.
2. Create a GitHub repository and upload the project files, keeping app.py, requirements.txt, Procfile, render.yaml, and templates/index.html at the repository root (templates is a folder).
3. Sign in to Render and create a new Web Service connected to that repository.
4. Use Python runtime. Build command: pip install -r requirements.txt
5. Start command: gunicorn app:app
6. Deploy. Once deployment finishes, open the public URL Render provides in iPhone Safari.

Hosting providers may change free-tier availability or require a payment method. The public URL is created by the hosting provider, not inside this ZIP.

LIMITATIONS: This app extracts image URLs present in public page HTML. Ko-fi may load images dynamically or restrict content; the app does not bypass supporter-only access. Do not add credentials or cookies to this app.
